import sys
sys.path.append('./Raspi-MotorHAT-python3')

from Raspi_MotorHAT import Raspi_MotorHAT, Raspi_DCMotor
from Raspi_PWM_Servo_Driver import PWM
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5 import QtSql
import atexit
import time


class pollingThread(QThread):
    def __init__(self):
        super().__init__()
        
    def run(self):
        self.db = QtSql.QSqlDatabase.addDatabase('QMYSQL')
        self.db.setHostName("3.35.8.78")
        self.db.setDatabaseName("DB_15_05")
        self.db.setUserName("SSAFY15_05_2")
        self.db.setPassword("1234")
        ok = self.db.open()
        print(ok)
        
        self.mh = Raspi_MotorHAT(addr=0x6f)
        self.myMotor = self.mh.getMotor(3)
        self.myMotor.setSpeed(100)
              
        self.pwm = PWM(0x6F)
        self.pwm.setPWMFreq(60)
        self.getQuery()


    def getQuery(self):
        while True:
            time.sleep(0.5)
            query = QtSql.QSqlQuery("select * from command2 order by time desc limit 1");
            query.next()
            cmdTime = query.record().value(0)
            cmdType = query.record().value(1)
            cmdArg = query.record().value(2)
            is_finish = query.record().value(3)
            print("is_finish = " + str(is_finish), is_finish==0)
            if is_finish == 0 :
                #update
                query = QtSql.QSqlQuery("update command2 set is_finish=1 where is_finish=0");
                print(cmdTime, cmdType, cmdArg)
                
                if cmdType == "go": self.go()
                if cmdType == "back": self.back()
                if cmdType == "left": self.left()
                if cmdType == "right": self.right()
                if cmdType == "middle": self.middle()
    def go(self):
        print("MOTOR GO")
        self.myMotor.setSpeed(100)
        self.myMotor.run(Raspi_MotorHAT.BACKWARD)
        #time.sleep(1)
        #self.myMotor.run(Raspi_MotorHAT.RELEASE)

        
    def back(self):
        print("MOTOR BACK")
        #self.myMotor.run(Raspi_MotorHAT.FORWARD)
        self.myMotor.run(Raspi_MotorHAT.RELEASE)

        
    def left(self):
        print("MOTOR LEFT")
        
    def right(self):
        print("MOTOR RIGHT")
        
    def middle(self):
        print("MOTOR MIDDLE")



th = pollingThread()
th.start()

app = QApplication([])

#infinity loop
while True:
    pass