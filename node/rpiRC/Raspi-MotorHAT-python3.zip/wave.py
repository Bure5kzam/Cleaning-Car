from gpiozero import DistanceSensor
from time import sleep

sensor = DistanceSensor(14,15)

while True:
    print(sensor.distance, "m")
    sleep(0.1)